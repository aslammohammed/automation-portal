//var express = require('express');
var dbOperations1 = require('./dboperations1');
//var router = express.Router();

//module.exports = router;


var reports = {
  executionTrend : async function(date){
    var data ={}
    var dailySql = `select T1.AUTOMATION_HOST,T2.HOST_NAME,T1.ENVIRONMENT,T1.TOTAL_PASSED,T1.TOTAL_FAILED,T1.TOTAL_SCRIPTS,T1.FEATURE from(
      select AUTOMATION_HOST,ENVIRONMENT,TOTAL_PASSED as TOTAL_PASSED , TOTAL_FAILED as TOTAL_FAILED, TOTAL_SCRIPTS as TOTAL_SCRIPTS,FEATURE from AUTOMATION_RUN_HEAD where trunc(RUN_STARTED) = to_date('`+date+`','DD-MM-YYYY') and STATUS ='Completed') T1 
          left join AUTOMATION_HOST_SERVER_MAP T2 on T1.AUTOMATION_HOST = T2.SERVER`;
    console.log("qyr:"+dailySql);
    var weeklySql = `select T1.AUTOMATION_HOST,T2.HOST_NAME,T1.ENVIRONMENT,T1.TOTAL_PASSED,T1.TOTAL_FAILED,T1.TOTAL_SCRIPTS,T1.FEATURE from(
      select AUTOMATION_HOST,ENVIRONMENT,SUM(TOTAL_PASSED) as TOTAL_PASSED , SUM(TOTAL_FAILED) as TOTAL_FAILED, SUM(TOTAL_SCRIPTS) as TOTAL_SCRIPTS,FEATURE from AUTOMATION_RUN_HEAD where RUN_STARTED>= trunc(to_date('`+date+`','DD-MM-YYYY'),'IW') and STATUS ='Completed' group by AUTOMATION_HOST,ENVIRONMENT,FEATURE) T1 
          left join AUTOMATION_HOST_SERVER_MAP T2 on T1.AUTOMATION_HOST = T2.SERVER`;
    var monthlySql = `select T1.AUTOMATION_HOST,T2.HOST_NAME,T1.ENVIRONMENT,T1.TOTAL_PASSED,T1.TOTAL_FAILED,T1.TOTAL_SCRIPTS,T1.FEATURE from(
            select AUTOMATION_HOST,ENVIRONMENT,SUM(TOTAL_PASSED) as TOTAL_PASSED , SUM(TOTAL_FAILED) as TOTAL_FAILED, SUM(TOTAL_SCRIPTS) as TOTAL_SCRIPTS,FEATURE from AUTOMATION_RUN_HEAD where RUN_STARTED>= trunc(to_date('`+date+`','DD-MM-YYYY'),'MM') and STATUS ='Completed' group by AUTOMATION_HOST,ENVIRONMENT,FEATURE) T1 
                left join AUTOMATION_HOST_SERVER_MAP T2 on T1.AUTOMATION_HOST = T2.SERVER`;
    let con = await dbOperations1.getConnection();

    var dayResults = await dbOperations1.runQuery(con, dailySql,{});
    data.dayData = dayResults.rows;
    var weekResults = await dbOperations1.runQuery(con, weeklySql,{});
    data.weekData = weekResults.rows;
    var monthResults = await dbOperations1.runQuery(con, monthlySql,{});
    data.monthData = monthResults.rows;
    console.log("Report Trend:"+JSON.stringify(data) );
    await dbOperations1.closeConnection(con);
      
    return data;
  } 
};

module.exports = reports;



