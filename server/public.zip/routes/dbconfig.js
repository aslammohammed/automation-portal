module.exports = {
    user: "eit",
    password: "root",
    connectString:"nsh00jpo.us.oracle.com:1521/dvols12",
    seuser: "seuser",
    sepassword: "retek",
    seconnectString:"slcibch.us.oracle.com:1521/dvols11",
    eit :{
        user: "eit",
        password: "root",
        connectString:"nsh00jpo.us.oracle.com:1521/dvols12"
    },
    selive:{
        user: "seuser",
        password: "retek",
        connectString:"slcibch.us.oracle.com:1521/dvols11"
    }
};